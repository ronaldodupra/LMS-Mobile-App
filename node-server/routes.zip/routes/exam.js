const router = require("express").Router();

var exam = require("../service/exam.service");
var verifyToken = require("../verifyToken");
var connection = require("../connection");
var moment = require("moment");

router.get("/", verifyToken, function (req, res) {
  const date = moment(Date.now()).format("YYYY-MM-DD");
  connection.connect(function () {
    var query = `select * from online_exam oe left join subject s on oe.subject_id = s.subject_id left join enroll e on oe.section_id= e.section_id where oe.examdate ='${date}'
     and e.student_id ='${req.user._id}'`;
    connection.query(query, function (err, result, field) {
      if (err) res.end(err);
      if (result && result.length) {
        res.end(JSON.stringify(result));
      }
    });
  });
});
router.get("/:id", verifyToken, function (req, res) {
  connection.connect(function () {
    var query = `select * from online_exam oe where oe.online_exam_id ='${req.params.id}'`;
    connection.query(query, function (err, result, field) {
      if (err) res.end(err);
      else if (!err) {
        var query2 = `select * from question_bank qb where qb.online_exam_id ='${req.params.id}'`;
        connection.query(query2, function (errQb, resultQb, fieldQb) {
          if (!errQb) {
            res.json({
              examDetails: result[0],
              questionBank: resultQb,
            });
          }
        });
      }
    });
  });
});
router.get("/:id/getExamResultId", verifyToken, function (req, res) {
  connection.connect(function () {
    var query = `select * from online_exam_result where online_exam_id ='${req.params.id}' and student_id ='${req.user._id}' limit 1`;
    connection.query(query, function (err, result) {
      if (err) {
        console.log(err);
      } else {
        res.json(result[0].online_exam_result_id);
      }
    });
  });
});
router.post("/:exam_result_id/:exam_id", verifyToken, function (req, res) {
  req.body.forEach((element) => {
    if (!Array.isArray(element.submitted_answer)) {
      if (
        element.submitted_answer == "true" ||
        element.submitted_answer == "false"
      ) {
      } else {
        console.log(element.submitted_answer);
        element.submitted_answer = JSON.stringify([element.submitted_answer]);
      }
    }
    if (Array.isArray(element.submitted_answer)) {
      const toString = JSON.stringify(element.submitted_answer);
      console.log(toString.replace(/"\"*/gi, "\\"));
      element.submitted_answer = toString;
    }
  });
  var toString = JSON.stringify(req.body);

  var replace = toString.replace(/\\/g, "\\\\");

  var query = `UPDATE online_exam_result SET answer_script='${replace}',status='submitted',exam_endtime='${Date.now()}' where online_exam_result_id='${
    req.params.exam_result_id
  }'`;

  connection.query(query, function (err, result) {
    if (err) throw err;
    console.log("1 record inserted");
    console.log(result);
    exam.checkAnswers(
      req.body,
      req.params.exam_result_id,
      req.params.exam_id,
      req.user._id
    );
    res.json("Submitted");
  });
});
router.post("/startExam", verifyToken, function (req, res) {
  var query = `INSERT into online_exam_result(online_exam_id,student_id,status,exam_started_timestamp) values ('${
    req.body.examId
  }','${req.user._id}','attended','${Date.now()}')`;
  connection.query(query, function (err, result) {
    if (err) {
      console.log(err);
    } else {
      res.json("Exam Attended");
    }
  });
});
module.exports = router;
