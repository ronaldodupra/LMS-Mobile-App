var connection = require("../connection");
var moment = require("moment");

module.exports = {
  checkAnswers: function (answer, exam_result_id, exam_id, student_id) {
    var numberOfItems = 0;
    var answer_obtained = 0;
    answer.forEach((x) => {
      var select = `SELECT * FROM question_bank where question_bank_id=${x.question_bank_id}`;
      connection.query(select, function (err, result) {
        var selectOne = result[0];

        if (selectOne.type == "multiple_choice") {
          if (x.correct_answers == x.submitted_answer) {
            answer_obtained += Number(selectOne.mark);
            console.log("multiple_choice " + answer_obtained);
          }
        } else if (selectOne.type == "true_false") {
          if (x.correct_answers == x.submitted_answer) {
            answer_obtained += Number(selectOne.mark);
            console.log("true_false " + answer_obtained);
          }
        } else if (selectOne.type == "image") {
          if (x.correct_answers == x.submitted_answer) {
            answer_obtained += Number(selectOne.mark);
            console.log("image" + answer_obtained);
          }
        } else if (selectOne.type == "identification") {
          if (
            x.correct_answers.toLowerCase() == x.submitted_answer.toLowerCase()
          ) {
            answer_obtained += Number(selectOne.mark);
            console.log("identification " + answer_obtained);
          }
        } else if (selectOne.type == "fill_in_the_blanks") {
          x.correct_answers = x.correct_answers.split(", ");
          x.submitted_answer = JSON.parse(x.submitted_answer);
          for (let i = 0; i < x.correct_answers.length; i++) {
            if (
              x.correct_answers[i].toLowerCase() ==
              x.submitted_answer[i].toLowerCase()
            ) {
              answer_obtained += Number(selectOne.mark);
              console.log("fill_in_the_blanks " + answer_obtained);
            }
            // this.insertEnumerationData();
          }
        } else if (selectOne.type == "chronological_order") {
          x.correct_answers = x.correct_answers.split(",");
          x.submitted_answer = JSON.parse(x.submitted_answer);
          for (let i = 0; i < x.correct_answers.length; i++) {
            x.correct_answers[i] = x.correct_answers[i].toLowerCase();
            x.submitted_answer[i] = x.submitted_answer[i].toLowerCase();
            if (x.correct_answers[i] == x.submitted_answer[i]) {
              answer_obtained += Number(selectOne.mark);
              console.log("chronological_order " + answer_obtained);
            }
          }
        } else if (selectOne.type == "enumeration") {
          x.correct_answers = x.correct_answers.toLowerCase().split(", ");
          x.submitted_answer = JSON.parse(x.submitted_answer.toLowerCase());
          var matchItems = x.correct_answers.filter(function (item) {
            return x.submitted_answer.includes(item);
          });
          matchItems.forEach((e) => {
            answer_obtained += Number(selectOne.mark);
            console.log("enumeration " + answer_obtained);
          });
        } else if (selectOne.type == "matching_type") {
          x.correct_answers = JSON.parse(selectOne.matching_type_answer);
          var matchingtype = JSON.parse(selectOne.matching_type);
          x.submitted_answer = JSON.parse(x.submitted_answer);

          for (let i = 0; i < matchingtype.length; i++) {
            if (x.correct_answers[i] == x.submitted_answer[i]) {
              answer_obtained += Number(selectOne.mark);
              console.log("matching_type " + answer_obtained);
            }
          }
        }
      });
      this.asyncFunction(() => {
        const date = moment(Date.now()).format("YYYY-MM-DD HH:mm:ss");
        numberOfItems++;
        connection.query(select, function (err, result) {
          var selectOne = result[0];
          if (
            selectOne.type == "chronological_order" ||
            selectOne.type == "enumeration" ||
            selectOne.type == "fill_in_the_blanks" ||
            selectOne.type == "matching_type"
          ) {
            x.submitted_answer.forEach((answer) => {
              var query = `INSERT INTO tbl_enumeration_data(online_exam_quiz_id,student_id,question_bank_id,answer,points,date_trans,type,question_type) VALUES
            ('${exam_id}','${student_id}','${x.question_bank_id}','${answer}','${selectOne.mark}','${date}','exam','${selectOne.type}')`;
              connection.query(query, function (err, result) {
                if (err) {
                  console.log(err);
                }
              });
            });
          }
        });

        if (numberOfItems === answer.length) {
          this.updateExamMarks(exam_result_id, answer_obtained);
        }
      });
    });
  },
  updateExamMarks: function (exam_result_id, answer_obtained) {
    var query = `UPDATE online_exam_result SET obtained_mark= ${answer_obtained} where online_exam_result_id=${exam_result_id}`;

    connection.query(query, function (err, result) {
      if (err) throw err;
      console.log("1 record inserted");
    });
  },
  asyncFunction: function (Update) {
    setTimeout(() => {
      Update();
    }, 100);
  },
};
